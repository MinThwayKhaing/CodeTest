var seatSelections = []; // {id, number}[]
var maxSeats = $('#seat-table').attr('data-max-seats');

$(document).ready(function(){
    //alert("Hello World");
    $('.seatSelectionSubmitButton').prop('disabled', true);

    $('.seat-available').click(function(event){
        event.preventDefault();

        var seatId = $(this).attr('data-seat-id');
        var seatNumber = $(this).attr('data-seat-number');

        if($(this).hasClass('seat-selected')) {
            seatSelections = seatSelections.filter(selection => selection.id != seatId);
            $(this).removeClass('seat-selected');
        } else {
            if(seatSelections.length < maxSeats) {
                seatSelections.push({
                    id: seatId,
                    number: seatNumber
                });
                console.log("Seat selections: ", seatSelections);
                $(this).addClass('seat-selected');
            }
        }

        let seatIdNumberPairs = seatSelections
            .map(selection => selection.id + "=" + selection.number)
            .join("&");
        console.log("Seat Pairs: " + seatIdNumberPairs);

        $("input.selectedIdNumberPairs").val(seatIdNumberPairs);
        $(".selectedSeatNumbers").text(seatSelections.map(selection => selection.number).join(", "));

        if(seatSelections.length != maxSeats) {
            $('.seatSelectionSubmitButton').prop('disabled', true);
        } else {
            $('.seatSelectionSubmitButton').prop('disabled', false);
        }
    });
});