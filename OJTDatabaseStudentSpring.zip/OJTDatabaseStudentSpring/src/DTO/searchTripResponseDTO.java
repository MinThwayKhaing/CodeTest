package DTO;

public class searchTripResponseDTO 
{
	String searchCity;
	String searchCityTo;
	String date;
	String seat;
	String Traveller;
	public String getSearchCity() {
		return searchCity;
	}
	public void setSearchCity(String searchCity) {
		this.searchCity = searchCity;
	}
	public String getSearchCityTo() {
		return searchCityTo;
	}
	public void setSearchCityTo(String searchCityTo) {
		this.searchCityTo = searchCityTo;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public String getTraveller() {
		return Traveller;
	}
	public void setTraveller(String traveller) {
		Traveller = traveller;
	}
	
}
