$(document).ready(function(){

    let selectedTime = null;
    let selectedOperatorId = null;

    let applyFilters = function () {
        $( "div.trip-result" ).each(function() {
            let time = $(this).attr("data-time");
            let operatorId = $(this).attr("data-operator-id");

            let timeMatched = (selectedTime)? selectedTime == time : true;
            let operatorIdMatched = (selectedOperatorId)? selectedOperatorId == operatorId : true;

            if(timeMatched && operatorIdMatched) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }

    let launchLightGallery = function(targetElement, photoUrls) {
        let photos = photoUrls.map(url => {
            return {
                "src": url,
                "subHtml": ""
            }
        });

        $(targetElement).lightGallery({
            dynamic: true,
            download: false,
            dynamicEl: photos
        });
    }

    $(document).on("click", '.time_option', function(event) {
        selectedTime = event.target.value;
        applyFilters();
    });

    $(document).on("click", '.operator_option', function(event) {
        selectedOperatorId = event.target.value;
        applyFilters();
    });

    $(document).on("click", '.gallery_launcher', function(event) {
        //alert(event.target.getAttribute("data-url"));
        let dataUrl = event.target.getAttribute("data-url");
        fetch(dataUrl)
          .then(response => response.json())
          .then(data => {
            if(Array.isArray(data)) {
                launchLightGallery(event.target, data);
            } else {
                console.log("Cannot show gallery. Data is not an array.");
            }
          });

    });
});

