package Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import Model.searchTripBean;

import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class searchTripController 
{
	/*
	 * @RequestMapping(value="/studentaddpage",method=RequestMethod.GET) public
	 * ModelAndView studentaddpage(ModelMap model) {
	 * 
	 * }
	 */
	 @RequestMapping(value = "/searchTrip", method = RequestMethod.POST)
		public String addStu(@ModelAttribute("searchbean")  searchTripBean searchbean, Model model) {
//insert  
		
		 	List courseList = new ArrayList<>(); 
			
				
		 	courseList.add(searchbean.getSearchCity());
			courseList.add(searchbean.getSearchCityTo());
			courseList.add(searchbean.getDate());
			courseList.add(searchbean.getSeat());
			courseList.add(searchbean.getTraveller());
				
			model.addAttribute("searchList", courseList);
				
						
				return "redirect:/studentsearchpage";
				
			}
		
}
